<?php
  require 'functions.php';
  $User = mysqli_fetch_assoc($a);
  $About = mysqli_fetch_assoc($b);
  
  $projects = data("SELECT * FROM Project");
  if(isset($_POST["submit"])){
      
      if(tambah($_POST) > 0){
          echo "
          <script>
               alert('Data berhasil dikirim');
          </script>
          ";
      }
      else {
          echo "gagal terkirim";
      }
  }
  
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Portofolio</title>
    <!-- CSS Bootsrap-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous" />
    <link rel="stylesheet" href="style.css">
  </head>
  <body>
    <!--- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark" style="background-color: black">
      <div class="container">
        <a class="navbar-brand" href="#">Sandra</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent" >
          <ul class="navbar-nav ms-auto">
            <li class="nav-item">
              <a class="nav-link active" aria-current="page" href="#">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">About</a>
            </li>
                <li class="nav-item">
                  <a class="nav-link" href="#">Project</a></li>
                <li class="nav-item">
                  <a class="nav-link" href="#">Contact</a></li>
              </ul>
            </li>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <!-- Akhir Navbar -->
    <!--jumbotron-->
    <div class="jumbotron text-center">
      <img src="shandra/<?= $User["foto"];?>" alt="" width="250" height="250" class="rounded-circle img-thumbnail"./>
      <h1 class="display-4"><?= $User["nama"];?></h1>
      <p class="lead"><?=$User["jabatan"];?> | <?= $User["perusahaan"];?></p>
     <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="#ffff" fill-opacity="1" d="M0,192L9.2,186.7C18.5,181,37,171,55,181.3C73.8,192,92,224,111,229.3C129.2,235,148,213,166,213.3C184.6,213,203,235,222,250.7C240,267,258,277,277,288C295.4,299,314,309,332,309.3C350.8,309,369,299,388,293.3C406.2,288,425,288,443,277.3C461.5,267,480,245,498,213.3C516.9,181,535,139,554,106.7C572.3,75,591,53,609,58.7C627.7,64,646,96,665,96C683.1,96,702,64,720,74.7C738.5,85,757,139,775,170.7C793.8,203,812,213,831,218.7C849.2,224,868,224,886,224C904.6,224,923,224,942,218.7C960,213,978,203,997,213.3C1015.4,224,1034,256,1052,261.3C1070.8,267,1089,245,1108,229.3C1126.2,213,1145,203,1163,186.7C1181.5,171,1200,149,1218,165.3C1236.9,181,1255,235,1274,213.3C1292.3,192,1311,96,1329,64C1347.7,32,1366,64,1385,106.7C1403.1,149,1422,203,1431,229.3L1440,256L1440,320L1430.8,320C1421.5,320,1403,320,1385,320C1366.2,320,1348,320,1329,320C1310.8,320,1292,320,1274,320C1255.4,320,1237,320,1218,320C1200,320,1182,320,1163,320C1144.6,320,1126,320,1108,320C1089.2,320,1071,320,1052,320C1033.8,320,1015,320,997,320C978.5,320,960,320,942,320C923.1,320,905,320,886,320C867.7,320,849,320,831,320C812.3,320,794,320,775,320C756.9,320,738,320,720,320C701.5,320,683,320,665,320C646.2,320,628,320,609,320C590.8,320,572,320,554,320C535.4,320,517,320,498,320C480,320,462,320,443,320C424.6,320,406,320,388,320C369.2,320,351,320,332,320C313.8,320,295,320,277,320C258.5,320,240,320,222,320C203.1,320,185,320,166,320C147.7,320,129,320,111,320C92.3,320,74,320,55,320C36.9,320,18,320,9,320L0,320Z"></path></svg>
    </div>
    <!-- akhir jumbotron -->
    <!-- About -->
    <section id="About">
      <div class="row text-center">
        <h2>About</h2>
      </div>
      <div class="row justify-content-center">
          <div class="cold-md-4 text-center"><?=$About["coloum1"];?></p>
         </div>
          <div class="col-md-4 text-center">
            <p><?=$About["coloum2"];?></p>
          </div>
      </div>
    </section>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="#a2d9ff" fill-opacity="1" d="M0,96L18.5,122.7C36.9,149,74,203,111,197.3C147.7,192,185,128,222,106.7C258.5,85,295,107,332,101.3C369.2,96,406,64,443,85.3C480,107,517,181,554,208C590.8,235,628,213,665,192C701.5,171,738,149,775,128C812.3,107,849,85,886,106.7C923.1,128,960,192,997,197.3C1033.8,203,1071,149,1108,138.7C1144.6,128,1182,160,1218,165.3C1255.4,171,1292,149,1329,128C1366.2,107,1403,85,1422,74.7L1440,64L1440,320L1421.5,320C1403.1,320,1366,320,1329,320C1292.3,320,1255,320,1218,320C1181.5,320,1145,320,1108,320C1070.8,320,1034,320,997,320C960,320,923,320,886,320C849.2,320,812,320,775,320C738.5,320,702,320,665,320C627.7,320,591,320,554,320C516.9,320,480,320,443,320C406.2,320,369,320,332,320C295.4,320,258,320,222,320C184.6,320,148,320,111,320C73.8,320,37,320,18,320L0,320Z"></path></svg>
    <!-- Akhir About -->
    
    <!-- Projects -->
    <section id ="projects">
    <div class="container">
      <div class="row text-center">
        <div class="col">
          <h2>Hi Everyone</h2>
        </div>
      </div>
      <div class="row text-center mb-3">
        <div class="col-sm-4">
          <div class="card">
          <img src="Project/Q.jpg" class="card-img-top" alt="ProjectQ">
          <div class="card-body">
          <p class="card-text">12 Rpl 3</p>
           </div>
          </div>
        </div>
          <div class="row text-center mb-3">
        <div class="col-sm-4">
          <div class="card">
          <img src="Project/Rpl.jpg" class="card-img-top" alt="ProjectQ">
          <div class="card-body">
          <p class="card-text">12 Rpl 3</p>
      </div>
    </div>
    </section>
    <!-- Akhir Projects -->
    <!-- Contact -->
    <section id="contact">
      <div class="container">
        <div class="row text-center mb-3">
          <div class="col">
            <h2>Contact Me</h2>
          </div>
        </div>
        <div class="row justify-content-center">
          <div class="col-md-6">
            <form action="" method="POST">
              <div class="mb-3">
                <label for="email" class"form-label">Email addres</label>
                <input type="email" name="email" class="form-control" id="email" aria-describedby="emailHelp"required/>
                <div id="emailHelp" class="form-text">we'll never share your email with anyone else</div>
                </div>
                <div class="mb-3">
                  <label for="nama" class="form-label">Nama</label>
                  <input type="text" name="nama_k" class="form-control" id="nama" required/>
                  </div>
                  <div class="mb-3">
                    <label for="pesan">Pesan</label>
                  <textarea name="pesan" class="form-control" placeholder="Leave a comment here" id="pesan".style="heigh: 100px" required></textarea>
                </div>
                <input type="submit" value="kirim" name="submit">
           </form>
          </div>
        </div>
      </div>
    </section>
    <!-- Akhir Contact -->
    
    <!-- Footer -->
    <footer class="bg-info text-white text-center pb-4">
      <p>Creater with <i class="bi bi-suit-heart-fill-text-danger"></i> by<a href="https://www.instagram.com/shndrakyransjnki_"class="text-white fw-bold">shndrakyransjnki_</a></p>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="#a2d9ff" fill-opacity="1" d="M0,128L48,112C96,96,192,64,288,90.7C384,117,480,203,576,224C672,245,768,203,864,160C960,117,1056,75,1152,53.3C1248,32,1344,32,1392,32L1440,32L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path></svg>
    </footer>
    <!-- Akhir Footer -->
    <!-- JavaScript-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
  </body>
</html>