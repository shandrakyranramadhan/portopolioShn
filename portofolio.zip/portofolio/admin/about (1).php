<?php
  include "header.php";
?>
<?php
  include "menu.php";
?>

<?php
  include "footer.php";
?>